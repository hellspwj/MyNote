#include<stdio.h>
int main()
{
	int a[3]={};
	printf("%p\n",a);
	printf("%p\n",&a);
	return 0;
}
