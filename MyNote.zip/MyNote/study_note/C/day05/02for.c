/*
   打印1－100之间的奇数
   */
#include<stdio.h>
int main()
{
	int num=0;
	int i=0;
	scanf("%d",&num);
	for(;num>0;num-=2);
//	{
//		if(num%2);
//		{
//			i++;
//			printf("%-2d ",num);
//		}
//		if(i%5==0) printf("\n");
//	}
	printf("end\n");
	return 0;
}
