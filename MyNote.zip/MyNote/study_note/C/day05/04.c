/*
   随机数演示
   */
#include<stdio.h>
#include<stdlib.h>
int main()
{
	printf("%d\n",rand());
	return 0;
}
