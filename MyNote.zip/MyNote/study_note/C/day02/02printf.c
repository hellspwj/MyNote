/*
   printf标准函数演示
   */
#include<stdio.h>
int main()
{
	printf("1\n");
	return 0;
}
