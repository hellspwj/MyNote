#include<stdio.h>
int main()
{
	printf("abc\n");
	printf("abc\rde\n");
	return 0;
}
