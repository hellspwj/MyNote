/*
   c语言程序结构演示
   日期：	2015－03－27
   版本：	1.0
   */
#include"01demo.h"
int main()
{
	5+10; //计算过程
	return 0;
}
