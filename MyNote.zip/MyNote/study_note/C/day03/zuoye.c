#include<stdio.h>
int main()
	{
		int num=0,num1=0,num2=0,num3=0;
		printf("请输入四个整数:");
		scanf("%d%d%d%d",&num,&num1,&num2,&num3);
		printf("四个整数的和为:%d\n",num+num1+num2+num3);
		return 0;
	}
