/*
   scanf标准函数演示
   */
#include<stdio.h>
int main()
{
	int num=0;
	printf("请输入一个数:");
	scanf("%d",&num);
	printf("%d\n",num);
	return 0;
}
