#include<stdio.h>
int main()
{
	char a;
	scanf("%d",&a);
	printf("%d",a);
	
	return 0;
}
