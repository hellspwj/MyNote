#include<stdio.h>
int main()
{
	int a[2][3];
	return 0;
}
