#include"03printnum.h"
void printnum(int num)
{
	printf("%d\n",num);
}
