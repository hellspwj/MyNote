#include<stdio.h>
#include "02add.h"
int main()
{
	int num=0;
	num=add(3,7);
	printf("num是%d\n",num);
	return 0;
}
