void printnum(int num);
