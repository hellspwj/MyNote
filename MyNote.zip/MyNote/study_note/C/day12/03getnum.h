void getnum(int *);
