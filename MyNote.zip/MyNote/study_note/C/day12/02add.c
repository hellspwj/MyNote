#include"02add.h"
int add(int num1,int num2)
{
	return num1+num2;
}
