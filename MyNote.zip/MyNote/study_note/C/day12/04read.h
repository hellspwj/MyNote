#ifndef __04READ_H__ 
#define __04READ_H__
void read(void);
extern int num;
#endif
