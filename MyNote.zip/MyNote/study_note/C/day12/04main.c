#include<stdio.h>
#include"04read.h"
int main()
{
	read();
	printf("hahaha是%d\n",num);
	return 0;
}

