#include"getnum.c"
void getnum(int *num)
{
	printf("请输入一个整数:");
	scanf("%d",num);
}
