/*
   字符串演示
   */
#include<stdio.h>
int main()
{
	char str[]={'a','b'};
//	str[2]='e';
//	char str[]="abc";
	printf("%s\n",str);
	printf("%d\n",sizeof(str));
	return 0;
}
