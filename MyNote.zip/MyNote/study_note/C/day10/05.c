#include<stdio.h>
#include<string.h>
int main()
{
	int arr[3];
	memset(arr,1,3);
	printf("%d %d %d\n",arr[0],arr[1],arr[2]);
	return 0;
}
