#include<iostream>
using namespace std;

int main(void)
{
	float a=1.0f;
	cout<<(int)a<<endl;
	cout<<(int&)a<<endl;
	return 0;
}
