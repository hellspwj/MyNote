#include<iostream>
using namespace std;

class A
{
	public:
		typedef unsigned int UINT;
		typedef enum
		{
			RED,GREEN,BLUE
		}color;
		class X{};
};
int main(void)
{

	return 0;
}
