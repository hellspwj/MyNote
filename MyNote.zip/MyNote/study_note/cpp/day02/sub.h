#ifndef _SUB_H
#define _SUB_H
int sub(int,int);
#endif
