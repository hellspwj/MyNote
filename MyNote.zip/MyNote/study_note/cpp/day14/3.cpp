#include<iostream>
using namespace std;
template<typename PEN>
class Rect
{
	public:
		virtual void draw(PEN const)
};
