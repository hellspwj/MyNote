#include<iostream>
using namespace std;
int main(void)
{
	bool b=true;
	cout<<sizeof(b)<<' '<<boolalpha<<b<<endl;
	return 0;
}
