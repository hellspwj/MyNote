#include<iostream>
#include<cstdio>
int main(void)
{
	int x,y;
	std::cout << "hello,world!" << std::endl;
	printf("hello,world!\n");
	std::cin >>x >>y;
	std::cout << x <<  '+' <<y << '=' << x+y <<std::endl;
	return 0;
}
