/********************************************************************************
** Form generated from reading UI file 'yaojiang.ui'
**
** Created: Mon May 4 14:07:01 2015
**      by: Qt User Interface Compiler version 4.8.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_YAOJIANG_H
#define UI_YAOJIANG_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QDialog>
#include <QtGui/QHeaderView>
#include <QtGui/QLabel>
#include <QtGui/QPushButton>

QT_BEGIN_NAMESPACE

class Ui_YaoJiang
{
public:
    QLabel *label;
    QLabel *pname;
    QPushButton *bstart;
    QPushButton *bstop;

    void setupUi(QDialog *YaoJiang)
    {
        if (YaoJiang->objectName().isEmpty())
            YaoJiang->setObjectName(QString::fromUtf8("YaoJiang"));
        YaoJiang->resize(400, 600);
        label = new QLabel(YaoJiang);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(108, 10, 68, 20));
        QFont font;
        font.setPointSize(15);
        label->setFont(font);
        pname = new QLabel(YaoJiang);
        pname->setObjectName(QString::fromUtf8("pname"));
        pname->setGeometry(QRect(180, 10, 81, 21));
        QPalette palette;
        QBrush brush(QColor(0, 0, 0, 255));
        brush.setStyle(Qt::SolidPattern);
        palette.setBrush(QPalette::Active, QPalette::WindowText, brush);
        QBrush brush1(QColor(170, 255, 255, 255));
        brush1.setStyle(Qt::SolidPattern);
        palette.setBrush(QPalette::Active, QPalette::Button, brush1);
        QBrush brush2(QColor(255, 255, 255, 255));
        brush2.setStyle(Qt::SolidPattern);
        palette.setBrush(QPalette::Active, QPalette::Light, brush2);
        QBrush brush3(QColor(212, 255, 255, 255));
        brush3.setStyle(Qt::SolidPattern);
        palette.setBrush(QPalette::Active, QPalette::Midlight, brush3);
        QBrush brush4(QColor(85, 127, 127, 255));
        brush4.setStyle(Qt::SolidPattern);
        palette.setBrush(QPalette::Active, QPalette::Dark, brush4);
        QBrush brush5(QColor(113, 170, 170, 255));
        brush5.setStyle(Qt::SolidPattern);
        palette.setBrush(QPalette::Active, QPalette::Mid, brush5);
        palette.setBrush(QPalette::Active, QPalette::Text, brush);
        palette.setBrush(QPalette::Active, QPalette::BrightText, brush2);
        palette.setBrush(QPalette::Active, QPalette::ButtonText, brush);
        palette.setBrush(QPalette::Active, QPalette::Base, brush2);
        palette.setBrush(QPalette::Active, QPalette::Window, brush1);
        palette.setBrush(QPalette::Active, QPalette::Shadow, brush);
        palette.setBrush(QPalette::Active, QPalette::AlternateBase, brush3);
        QBrush brush6(QColor(255, 255, 220, 255));
        brush6.setStyle(Qt::SolidPattern);
        palette.setBrush(QPalette::Active, QPalette::ToolTipBase, brush6);
        palette.setBrush(QPalette::Active, QPalette::ToolTipText, brush);
        palette.setBrush(QPalette::Inactive, QPalette::WindowText, brush);
        palette.setBrush(QPalette::Inactive, QPalette::Button, brush1);
        palette.setBrush(QPalette::Inactive, QPalette::Light, brush2);
        palette.setBrush(QPalette::Inactive, QPalette::Midlight, brush3);
        palette.setBrush(QPalette::Inactive, QPalette::Dark, brush4);
        palette.setBrush(QPalette::Inactive, QPalette::Mid, brush5);
        palette.setBrush(QPalette::Inactive, QPalette::Text, brush);
        palette.setBrush(QPalette::Inactive, QPalette::BrightText, brush2);
        palette.setBrush(QPalette::Inactive, QPalette::ButtonText, brush);
        palette.setBrush(QPalette::Inactive, QPalette::Base, brush2);
        palette.setBrush(QPalette::Inactive, QPalette::Window, brush1);
        palette.setBrush(QPalette::Inactive, QPalette::Shadow, brush);
        palette.setBrush(QPalette::Inactive, QPalette::AlternateBase, brush3);
        palette.setBrush(QPalette::Inactive, QPalette::ToolTipBase, brush6);
        palette.setBrush(QPalette::Inactive, QPalette::ToolTipText, brush);
        palette.setBrush(QPalette::Disabled, QPalette::WindowText, brush4);
        palette.setBrush(QPalette::Disabled, QPalette::Button, brush1);
        palette.setBrush(QPalette::Disabled, QPalette::Light, brush2);
        palette.setBrush(QPalette::Disabled, QPalette::Midlight, brush3);
        palette.setBrush(QPalette::Disabled, QPalette::Dark, brush4);
        palette.setBrush(QPalette::Disabled, QPalette::Mid, brush5);
        palette.setBrush(QPalette::Disabled, QPalette::Text, brush4);
        palette.setBrush(QPalette::Disabled, QPalette::BrightText, brush2);
        palette.setBrush(QPalette::Disabled, QPalette::ButtonText, brush4);
        palette.setBrush(QPalette::Disabled, QPalette::Base, brush1);
        palette.setBrush(QPalette::Disabled, QPalette::Window, brush1);
        palette.setBrush(QPalette::Disabled, QPalette::Shadow, brush);
        palette.setBrush(QPalette::Disabled, QPalette::AlternateBase, brush1);
        palette.setBrush(QPalette::Disabled, QPalette::ToolTipBase, brush6);
        palette.setBrush(QPalette::Disabled, QPalette::ToolTipText, brush);
        pname->setPalette(palette);
        pname->setFont(font);
        pname->setAutoFillBackground(true);
        bstart = new QPushButton(YaoJiang);
        bstart->setObjectName(QString::fromUtf8("bstart"));
        bstart->setGeometry(QRect(60, 530, 97, 27));
        bstop = new QPushButton(YaoJiang);
        bstop->setObjectName(QString::fromUtf8("bstop"));
        bstop->setGeometry(QRect(230, 530, 97, 27));

        retranslateUi(YaoJiang);

        QMetaObject::connectSlotsByName(YaoJiang);
    } // setupUi

    void retranslateUi(QDialog *YaoJiang)
    {
        YaoJiang->setWindowTitle(QApplication::translate("YaoJiang", "YaoJiang", 0, QApplication::UnicodeUTF8));
        label->setText(QApplication::translate("YaoJiang", "\344\270\255\345\245\226\344\272\272:", 0, QApplication::UnicodeUTF8));
        pname->setText(QString());
        bstart->setText(QApplication::translate("YaoJiang", "\345\274\200\345\247\213", 0, QApplication::UnicodeUTF8));
        bstop->setText(QApplication::translate("YaoJiang", "\345\201\234\346\255\242", 0, QApplication::UnicodeUTF8));
    } // retranslateUi

};

namespace Ui {
    class YaoJiang: public Ui_YaoJiang {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_YAOJIANG_H
