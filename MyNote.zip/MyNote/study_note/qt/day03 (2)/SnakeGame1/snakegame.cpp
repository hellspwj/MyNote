#include "snakegame.h"
SnakeGame::SnakeGame(){
    this->resize(800,600);
}
/* 产生新食物的函数 */
QLabel*  SnakeGame::getNewFood(){

}
/* 蛇移动的函数 根据方向每次移动一个步长 */
void   SnakeGame::snakeMove(){

}
/* 使用键盘事件处理函数 控制方向 */
void SnakeGame::keyPressEvent(QKeyEvent *e){

}

